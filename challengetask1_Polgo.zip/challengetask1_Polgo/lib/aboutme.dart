import 'package:flutter/material.dart';

class AboutMeScreen extends StatefulWidget {
  const AboutMeScreen({super.key});

  @override
  _AboutMeScreenState createState() => _AboutMeScreenState();
}

class _AboutMeScreenState extends State<AboutMeScreen> {
  bool _isImageVisible = true;

  void _toggleImage() {
    setState(() {
      _isImageVisible = !_isImageVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color.fromARGB(215, 4, 0, 243),
            Color.fromARGB(255, 255, 255, 255)
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedOpacity(
              opacity: _isImageVisible ? 1.0 : 0.1,
              duration: const Duration(milliseconds: 500),
              child: Image.asset(
                'assets/images/resume.png',
                width: 150,
                height: 200,
              ),
            ),
            const Text(
              'Showcase Your Story, Elevate Your Journey',
              style: TextStyle(fontSize: 40, color: Colors.white),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 75),
            ElevatedButton.icon(
              onPressed: _toggleImage,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.blue[900],
                backgroundColor: Colors.white,
                side: const BorderSide(color: Colors.white),
              ),
              icon: const Icon(Icons.info_rounded),
              label: const Text("About Me", style: TextStyle(fontSize: 40)),
            ),
          ],
        ),
      ),
    );
  }
}
