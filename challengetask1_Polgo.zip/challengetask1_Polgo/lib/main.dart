import 'package:challengetask1/aboutme.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
        appBar: AppBar(
          title: const Text("Resume"),
        ),
        body:AboutMeScreen()
    ),
  ));
}

